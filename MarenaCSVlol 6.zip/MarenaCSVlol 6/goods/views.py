# goods/views.py
from django.shortcuts import render, redirect
from django.contrib.auth.views import LoginView
from django.urls import reverse_lazy
from .models import Goods, IssuedGoods, StudentLog
from django.shortcuts import render, redirect, get_object_or_404
from django.utils import timezone
import pytz
import csv
import os
from io import StringIO
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth.models import User
from django.http import HttpResponse, HttpResponseRedirect, JsonResponse  



def admin_login(request):
    return render(request, 'goods/admin_login.html')

def maintenance_login(request):
    return render(request, 'goods/maintenance_login.html')

def landing_page(request):
    return render(request, 'goods/landing_page.html')

def dashboard(request):
    return render(request, 'goods/dashboard.html')

def goods_list(request):
    csv_file_path = 'data/available_goods.csv'

    
    with open(csv_file_path, 'r') as file:
        reader = csv.DictReader(file)
        goods_data = list(reader)

    context = {'goods': goods_data}
    return render(request, 'goods/goods_list.html', context)

def issued_goods_list(request):
    issued_goods_csv_path = 'data/issued_goods.csv'
    with open(issued_goods_csv_path, 'r') as file:
        reader = csv.DictReader(file)
        goods_data = list(reader)

    context = {'issued_goods': goods_data}
    return render(request, 'goods/issued_goods_list.html', context)

def student_logs_list(request):
    student_log_csv_path = 'data/student_logs.csv'
    with open(student_log_csv_path, 'r') as file:
        reader = csv.DictReader(file)
        goods_data = list(reader)

    context = {'student_logs': goods_data}
    return render(request, 'goods/student_logs_list.html', context)


class MyLoginView(LoginView):
    success_url = reverse_lazy('dashboard')
    

def issue_equipment(request):
    csv_file_path = 'data/available_goods.csv'
    issued_goods_csv_path = 'data/issued_goods.csv'
    student_log_csv_path = 'data/student_logs.csv'

    
    with open(csv_file_path, 'r') as file:
        reader = csv.DictReader(file)
        goods_data = list(reader)

    context = {'goods_items': goods_data}
    
    if request.method == 'POST':
        
        equipment = int(request.POST.get('equipment'))
        item_name = request.POST.get('item_name')
        name = request.POST.get('name')
        department = request.POST.get('department')
        regno = request.POST.get('registration_number')
        phoneno = request.POST.get('phone_number')
        quantity = int(request.POST.get('quantity'))

        
        with open(issued_goods_csv_path, 'r') as issued_file:
            issued_reader = csv.DictReader(issued_file)
            issued_goods_data = list(issued_reader)

        
        if any(item['regno'] == regno for item in issued_goods_data):
            # If regno is already in issued goods, redirect to error page
            messages.error(request, 'Equipment already issued to the student with the provided registration number.')
            return redirect('issue_equipment')
                    

        # Find the item in the CSV data
        for item in goods_data:
            if int(item['item_id']) == equipment and int(item['available_quantity']) >= quantity:
                #
                item['available_quantity'] = str(int(item['available_quantity']) - quantity)
               
                ist = pytz.timezone('Asia/Kolkata')  
                current_datetime_ist = timezone.now().astimezone(ist)
               
                with open(csv_file_path, 'w', newline='') as goods_file:
                    fieldnames = ['item_id', 'item_name', 'total_quantity', 'available_quantity']
                    writer = csv.DictWriter(goods_file, fieldnames=fieldnames)
                    writer.writeheader()
                    writer.writerows(goods_data)

               
                with open(issued_goods_csv_path, 'a', newline='') as issued_goods_file:
                    fieldnames = ['item_id', 'item_name', 'name', 'department', 'regno', 'phoneno', 'no_issued', 'date_of_issue', 'time_of_issue']
                    issued_goods_writer = csv.DictWriter(issued_goods_file, fieldnames=fieldnames)
                    issued_goods_writer.writerow({
                        'item_id': equipment,
                        'item_name': item['item_name'],
                        'name': name,
                        'department': department,
                        'regno': regno,
                        'phoneno': phoneno,
                        'no_issued': quantity,
                        'date_of_issue': current_datetime_ist.date(),
                        'time_of_issue': current_datetime_ist.time(),
                    })

                
                with open(student_log_csv_path, 'a', newline='') as student_log_file:
                    fieldnames = ['item_id', 'item_name', 'name', 'department', 'regno', 'phoneno', 'no_issued', 'date_of_issue', 'time_of_issue']
                    student_log_writer = csv.DictWriter(student_log_file, fieldnames=fieldnames)
                    student_log_writer.writerow({
                        'item_id': equipment,
                        'item_name': item['item_name'],
                        'name': name,
                        'department': department,
                        'regno': regno,
                        'phoneno': phoneno,
                        'no_issued': quantity,
                        'date_of_issue': current_datetime_ist.date(),
                        'time_of_issue': current_datetime_ist.time(),
                    })

                print("reached redirect to viewing")
                return redirect('view_issued_goods')  

        
        print("Entered else")
        messages.error(request, 'Error! Please make sure you entered the correct quantity. The product may be unavailable.') 

   
    return render(request, 'goods/issue_equipment.html', context)

def return_equipment(request):
    csv_file_path = 'data/available_goods.csv'
    issued_goods_csv_path = 'data/issued_goods.csv'
    student_log_csv_path = 'data/student_logs.csv'

    
    with open(issued_goods_csv_path, 'r') as file:
        reader = csv.DictReader(file)
        issued_goods_data = list(reader)

    context = {'issued_goods': issued_goods_data}

    if request.method == 'POST':
        
        regno = request.POST.get('registration_number')
        penalty_str = request.POST.get('penalty')

        
        penalty = int(penalty_str) if penalty_str and penalty_str.strip() else 0



       
        issued_goods_csv_path = 'data/issued_goods.csv'
        student_log_csv_path = 'data/student_logs.csv'
        available_goods_csv_path = 'data/available_goods.csv'

        
        with open(issued_goods_csv_path, 'r') as issued_goods_file:
            issued_goods_reader = csv.DictReader(issued_goods_file)
            issued_goods_data = list(issued_goods_reader)

        
        for item in issued_goods_data:

            print(regno)
            print(item)

            if item['regno'] == regno:

                ist = pytz.timezone('Asia/Kolkata')  
                current_datetime_ist = timezone.now().astimezone(ist)

                
                with open(student_log_csv_path, 'a', newline='') as student_log_file:
                    fieldnames = ['item_id', 'item_name', 'name', 'department', 'regno', 'phoneno', 'no_issued', 'date_of_issue', 'time_of_issue', 'returned', 'return_date', 'return_time', 'penalty']
                    student_log_writer = csv.DictWriter(student_log_file, fieldnames=fieldnames)
                    student_log_writer.writerow({
                        'item_id': item['item_id'],
                        'item_name': item['item_name'],
                        'name': item['name'],
                        'department': item['department'],
                        'regno': item['regno'],
                        'phoneno': item['phoneno'],
                        'no_issued': item['no_issued'],
                        'date_of_issue': item['date_of_issue'],
                        'time_of_issue': item['time_of_issue'],
                        'returned': 'True',
                        'return_date': current_datetime_ist.date(),
                        'return_time': current_datetime_ist.time(),
                        'penalty': penalty,
                    })

                
                with open(available_goods_csv_path, 'r') as available_goods_file:
                    available_goods_reader = csv.DictReader(available_goods_file)
                    available_goods_data = list(available_goods_reader)

                for available_item in available_goods_data:
                    if available_item['item_id'] == item['item_id']:
                        available_item['available_quantity'] = str(int(available_item['available_quantity']) + int(item['no_issued']))

                with open(available_goods_csv_path, 'w', newline='') as available_goods_file:
                    fieldnames = ['item_id', 'item_name', 'total_quantity', 'available_quantity']
                    available_goods_writer = csv.DictWriter(available_goods_file, fieldnames=fieldnames)
                    available_goods_writer.writeheader()
                    available_goods_writer.writerows(available_goods_data)

                
                issued_goods_data.remove(item)

                with open(issued_goods_csv_path, 'w', newline='') as issued_goods_file:
                    fieldnames = ['item_id', 'item_name', 'name', 'department', 'regno', 'phoneno', 'no_issued', 'date_of_issue', 'time_of_issue']
                    issued_goods_writer = csv.DictWriter(issued_goods_file, fieldnames=fieldnames)
                    issued_goods_writer.writeheader()
                    issued_goods_writer.writerows(issued_goods_data)

                print("reached redirect to return success")
                return redirect('view_student_logs')  

    
    return render(request, 'goods/return_equipment.html', context)

class AdminLoginView(LoginView):
    template_name = 'goods/admin_login.html'
    success_url = '/goods/dashboard/'

    def post(self, request, *args, **kwargs):
        username = request.POST.get('uname')
        password = request.POST.get('psw')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect(self.success_url)
        else:
            messages.error(request, 'Incorrect username or password, please try again.')
            return render(request, self.template_name, {})

class MyLoginView(LoginView):
    success_url = reverse_lazy('dashboard')

class MaintenanceLoginView(LoginView):
    template_name = 'goods/maintenance_login.html'
    success_url = '/goods/dashboard/' 
    def post(self, request):
        username = request.POST.get('uname')
        password = request.POST.get('psw')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)
            return redirect(self.success_url)
        else:
            messages.error(request, 'Incorrect username or password')
            return render(request, self.template_name, {})
        
from django.http import HttpResponse
import csv
from .models import StudentLog

from django.http import HttpResponse
from django.conf import settings
import os

def export_student_logs_csv(request):
   
    relative_path = ('data\student_logs.csv')
    file_path = os.path.join(settings.BASE_DIR, relative_path)


    file_name = os.path.basename(file_path)

    with open(file_path, 'rb') as csv_file:
        response = HttpResponse(csv_file.read(), content_type='text/csv')
        response['Content-Disposition'] = f'attachment; filename="{file_name}"'

    return response

def export_issued_goods_csv(request):
    
    relative_path = 'data/issued_goods.csv'
    file_path = os.path.join(settings.BASE_DIR, relative_path)

    file_name = os.path.basename(file_path)

    with open(file_path, 'rb') as csv_file:
        response = HttpResponse(csv_file.read(), content_type='text/csv')
        response['Content-Disposition'] = f'attachment; filename="{file_name}"'

    return response
  

def export_available_goods_csv(request):
    relative_path = 'data/available_goods.csv'  
    file_path = os.path.join(settings.BASE_DIR, relative_path)
    file_name = os.path.basename(file_path)

    with open(file_path, 'rb') as csv_file:
        response = HttpResponse(csv_file.read(), content_type='text/csv')
        response['Content-Disposition'] = f'attachment; filename="{file_name}"'

    return response

def modify_inventory(request):
    
    csv_file_path = 'data/available_goods.csv'
    issued_goods_csv_path = 'data/issued_goods.csv'
    student_log_csv_path = 'data/student_logs.csv'

    
    with open(csv_file_path, 'r') as file:
        reader = csv.DictReader(file)
        goods_data = list(reader)

    context = {'available_goods': goods_data}
    
    if request.method == 'POST':
        try:
            item_id = int(request.POST.get('item_name'))
            total_quantity_change = int(request.POST.get('total_quantity'))

            
            for item in goods_data:
                if int(item['item_id']) == item_id:
                    
                    item['total_quantity'] = str(int(item['total_quantity']) + total_quantity_change)
                    
                    if (int(item['available_quantity']) + total_quantity_change) >= 0:
                        item['available_quantity'] = str(int(item['available_quantity']) + total_quantity_change)

                        
                        with open(csv_file_path, 'w', newline='') as goods_file:
                            fieldnames = ['item_id', 'item_name', 'total_quantity', 'available_quantity']
                            writer = csv.DictWriter(goods_file, fieldnames=fieldnames)
                            writer.writeheader()
                            writer.writerows(goods_data)

                        messages.success(request, f'Inventory for item {item_id} modified successfully.')
                        return redirect('goods_list')  
                    else:
                        messages.error(request, 'Error! Available quantity cannot be negative.')
                        return HttpResponseRedirect(request.path_info)  

            # Handle cases where goods with the given ID do not exist
            messages.error(request, f'Error! Item with ID {item_id} not found.')

        except ValueError:
            messages.error(request, 'Error! Please enter valid numeric values.')

    return render(request, 'goods/modify_inventory.html' , context)


def add_new_item(request):
    if request.method == 'POST':
        
        item_name = request.POST.get('item_name')
        total_quantity = int(request.POST.get('total_quantity'))

        
        csv_file_path = 'data/available_goods.csv'
        with open(csv_file_path, 'r') as file:
            reader = csv.DictReader(file)
            goods_data = list(reader)

        
        last_item = goods_data[-1] if goods_data else {'item_id': '0'}
        next_item_id = str(int(last_item['item_id']) + 1)

        
        goods_data.append({
            'item_id': next_item_id,
            'item_name': item_name,
            'total_quantity': str(total_quantity),
            'available_quantity': str(total_quantity),  
        })

        
        with open(csv_file_path, 'w', newline='') as goods_file:
            fieldnames = ['item_id', 'item_name', 'total_quantity', 'available_quantity']
            writer = csv.DictWriter(goods_file, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(goods_data)

        messages.success(request, 'Item added successfully.')
        return redirect('view_available_goods')  
    
    return render(request, 'goods/add_new_item.html')


def remove_item(request):
    csv_file_path = 'data/available_goods.csv'

    if request.method == 'POST':
        item_id_to_remove = request.POST.get('item_id')

        
        with open(csv_file_path, 'r') as file:
            reader = csv.DictReader(file)
            available_goods_data = list(reader)

        
        for index, item in enumerate(available_goods_data):
            if item['item_id'] == item_id_to_remove:
                
                removed_item_name = item['item_name']
                available_goods_data.pop(index)

                # Update the item_id of remaining items
                for remaining_item in available_goods_data:
                    if int(remaining_item['item_id']) > int(item_id_to_remove):
                        remaining_item['item_id'] = str(int(remaining_item['item_id']) - 1)

                # Write the modified data back to available_goods.csv
                with open(csv_file_path, 'w', newline='') as goods_file:
                    fieldnames = ['item_id', 'item_name', 'total_quantity', 'available_quantity']
                    writer = csv.DictWriter(goods_file, fieldnames=fieldnames)
                    writer.writeheader()
                    writer.writerows(available_goods_data)

                messages.success(request, f'Item "{removed_item_name}" removed successfully.')
                return redirect('view_available_goods')  
            
        # Handle cases where the item with the given ID is not found
        messages.error(request, f'Error! Item with ID {item_id_to_remove} not found.')


    with open(csv_file_path, 'r') as file:
        reader = csv.DictReader(file)
        available_goods_data = list(reader)

    context = {'available_goods': available_goods_data}
    return render(request, 'goods/remove_item.html', context)