# myapp/urls.py
from django.shortcuts import render
from django.urls import path
from .views import MyLoginView, admin_login, export_available_goods_csv, export_issued_goods_csv, export_student_logs_csv, maintenance_login, landing_page, dashboard, \
    issue_equipment, return_equipment, goods_list, issued_goods_list, student_logs_list, \
    goods_list, issued_goods_list, student_logs_list , AdminLoginView , MaintenanceLoginView , modify_inventory , add_new_item , remove_item

from django.contrib import admin
from django.urls import path, include
from .views import MyLoginView, admin_login, maintenance_login, landing_page, dashboard, \
    issue_equipment, return_equipment, goods_list, issued_goods_list, student_logs_list, AdminLoginView, MaintenanceLoginView

urlpatterns = [
    path('', landing_page, name='landing_page'),
    path('dashboard/', dashboard, name='dashboard'),
    path('admin_login/', AdminLoginView.as_view(), name='admin_login_view'),
    path('maintenance_login/', MaintenanceLoginView.as_view(), name='maintenance_login'),

    # URLs for the buttons on the dashboard
    path('issue_equipment/', issue_equipment, name='issue_equipment'),
    path('return_equipment/', return_equipment, name='return_equipment'),
    path('view_available_goods/', goods_list, name='view_available_goods'),
    path('view_issued_goods/', issued_goods_list, name='view_issued_goods'),
    path('view_student_logs/', student_logs_list, name='view_student_logs'),

    # URLs for the goods (remove duplicated paths)
    path('goods/', goods_list, name='goods_list'),
    path('issued_goods/', issued_goods_list, name='issued_goods_list'),
    path('student_logs/', student_logs_list, name='student_logs_list'),

    #URLS for downloading csv file
    path('export-csv/', export_student_logs_csv, name='export_student_logs_csv'),
    path('export-issued-goods/', export_issued_goods_csv, name='export_issued_goods_csv'),
    path('export-available-goods-csv/', export_available_goods_csv, name='export_available_goods_csv'),

    path('modify_inventory/', modify_inventory, name='modify_inventory'),
    path('add_new_item/', add_new_item, name='add_new_item'),
    path('remove-item/', remove_item, name='remove_item'),
]
    

